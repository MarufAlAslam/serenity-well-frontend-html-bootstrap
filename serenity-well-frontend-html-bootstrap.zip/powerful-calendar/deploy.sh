npx uglifyjs calendar.js -o calendar.min.js -c -m
surge ./